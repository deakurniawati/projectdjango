from django.db import models


class Kecamatan(models.Model):
    Kecamatan = models.CharField(max_length=100)

    def __str__(self):
        return self.Kecamatan

class penduduk (models.Model):
    Nik = models.CharField(max_length=10)
    Nama = models.CharField(max_length=50)
    Kecamatan = models.ForeignKey(Kecamatan, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.Nik
