from django.contrib import admin

from . models import penduduk, Kecamatan

admin.site.register(penduduk)
admin.site.register(Kecamatan)