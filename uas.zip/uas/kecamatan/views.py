from django.shortcuts import render

from . forms import Kecamatan

from . models import Kecamatan

def index(request):
    kecamatan = Kecamatan()

    context = {
        'Kecamatan':kecamatan,
    }

    if request.method == "POST":
        Kecamatan.objects.create(
            Nik = request.POST.get('Nik'),
            Nama = request.POST.get('Nama'),
            Kecamatan = request.POST.get('Kecamatan'),
        )

    return render(request, 'kecamatan/index.html', context)
