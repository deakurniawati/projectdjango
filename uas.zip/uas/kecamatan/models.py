from django.db import models

class Kecamatan(models.Model):
    Nik = models.CharField(max_length=10)
    Nama = models.CharField(max_length=50)
    Kecamatan = models.TextField()

    def __str__(self):
        return self.Nik
