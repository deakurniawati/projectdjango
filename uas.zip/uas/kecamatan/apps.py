from django.apps import AppConfig


class KecamatanConfig(AppConfig):
    name = 'kecamatan'
