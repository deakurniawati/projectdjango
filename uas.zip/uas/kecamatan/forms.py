from django import forms

class Kecamatan (forms.Form):
    Nik = forms.CharField(max_length=10)
    Nama = forms.CharField(max_length=50)
    Kecamatan = forms.CharField(
        widget= forms.Textarea
    )